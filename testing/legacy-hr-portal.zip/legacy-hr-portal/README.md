# Legacy HR Portal

A circa-2012 internal HR portal used by a mid-size company to manage employee
records, payslips, and performance reviews. Originally written in PHP 5 on
Apache + MySQL, it has been running in production largely unchanged for years.
A small operations team maintains it; there is no dedicated security team.

This project exists so we can exercise the threat modeler on a representative
**legacy monolithic web application** with a classic LAMP stack.

## What the application does

- HR staff log in with a username + password.
- Employees can view their own profile, upload a photo, and download
  their latest payslip PDF.
- Managers can view and edit employees in their department.
- An "admin" flag on the user record unlocks a privileged dashboard used
  to create new employees, reset passwords, and run salary exports.
- A nightly cron job emails CSV payroll exports to finance.

## Tech stack

- PHP 5.6 (upgraded in-place to 7.4 a few years ago)
- Apache 2.4 with `mod_php`
- MySQL 5.7 (single instance, running on the same host)
- jQuery 1.8 + Bootstrap 3 on the front-end
- PHPMailer 5.x over plain SMTP to an internal relay
- No container, no CI, deployed via `rsync` from an engineer's laptop

## High-level architecture

```
        ┌────────────────────┐
        │  Employee / HR     │
        │  Web Browser       │
        │  (office LAN + VPN)│
        └─────────┬──────────┘
                  │ HTTP  (port 80, HTTPS terminates at corporate LB)
                  ▼
        ┌────────────────────┐            ┌──────────────────────┐
        │  Apache + mod_php  │ ─────────▶ │  Local filesystem    │
        │  /var/www/hr       │  reads &   │  /var/www/hr/uploads │
        │                    │  writes    │  (photos, CSV dumps) │
        └─────────┬──────────┘            └──────────────────────┘
                  │
                  │ MySQLi (unencrypted, same host)
                  ▼
        ┌────────────────────┐
        │  MySQL 5.7          │
        │  db: hr_portal      │
        │  tables: users,     │
        │  employees, payslips│
        └─────────┬──────────┘
                  │
                  │ SMTP (plain, no TLS)
                  ▼
        ┌────────────────────┐
        │  Internal mail     │
        │  relay (Postfix)   │
        └────────────────────┘
```

See `ARCHITECTURE.md` for the trust boundaries, data flows, and
asset inventory used for threat modeling.

## Directory layout

```
legacy-hr-portal/
├── ARCHITECTURE.md       # DFD + trust boundaries + assets
├── composer.json         # PHPMailer dependency
├── config/settings.ini   # DB credentials, SMTP, admin email
├── db.php                # MySQLi connection helper
├── index.php             # Login form + session bootstrap
├── dashboard.php         # Post-login landing page
├── upload.php            # Employee photo upload
├── api/employees.php     # Search endpoint used by manager UI
├── cron/export_payroll.php # Nightly CSV export + email
└── uploads/.gitkeep
```

## Known compromises (left intentionally)

This codebase is a demo target. It intentionally contains patterns that
were common in legacy PHP applications of this era and that are expected
to surface during threat modeling:

- Credentials and SMTP secrets in a plaintext `.ini` file.
- MD5-hashed passwords.
- String-concatenated SQL queries.
- `admin=1` as a URL parameter short-circuit.
- Uploads written directly under the webroot.
- No CSRF tokens, no rate limiting, no audit logging.
- HTTPS is assumed to be handled by the corporate load balancer; the app
  itself speaks plain HTTP.

These are features of the target system, not bugs to fix.
