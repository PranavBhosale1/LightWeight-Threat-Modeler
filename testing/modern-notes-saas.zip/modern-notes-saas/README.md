# Modern Notes SaaS

A small-but-real note-taking SaaS, designed in 2025. Users sign up, organize
notes into workspaces, attach files, share notes via public links, and
subscribe to outbound webhooks when notes change.

The project is intentionally modest in size but is structured the way most
new greenfield services are structured today: a Vite + React SPA, a
stateless Node/Express API, Postgres for persistence, Redis for rate
limiting and short-lived tokens, and an S3-compatible object store for
attachments. The whole thing runs under `docker compose` locally and is
intended to be deployed to a managed container platform.

It exists here as a **modern greenfield** counterpart to the Legacy HR
Portal, so the threat modeler can be exercised against a system whose risks
are less obvious and more architectural than code-level.

## What the application does

- Users sign up with email + password. Passwords are hashed with Argon2id.
- A short-lived JWT (access token) + rotating refresh token are returned
  on login.
- Users create **workspaces**; each workspace has **notes** and **attachments**.
- A note can be shared via a public, unguessable link (`/s/:token`).
- Tenants can register **outbound webhooks**; the API POSTs to those URLs
  whenever a note is created or updated.
- Attachments are uploaded via a presigned URL directly to object storage.

## Tech stack

- **web/** Vite + React 18 + TypeScript SPA, served by nginx.
- **server/** Node 20 + Express + `pg` + `ioredis` + `jsonwebtoken` +
  `argon2`.
- **Postgres 16** — primary data store.
- **Redis 7** — rate limits, refresh-token revocation list, share-link
  cache.
- **S3-compatible object store** (MinIO in local dev) — attachments.
- **Docker Compose** for local dev, Kubernetes-style deployment in prod.

## High-level architecture (Mermaid)

```mermaid
flowchart LR
    U[Browser / SPA user] -->|HTTPS| CDN[CDN / TLS edge]
    CDN --> NGX[nginx<br/>serves React SPA]
    NGX -->|/api proxy| API[Node/Express API]

    API -->|pg| PG[(Postgres 16)]
    API -->|redis| RDS[(Redis 7)]
    API -->|presigned PUT| S3[(Object Store<br/>S3 / MinIO)]
    API -->|HTTPS webhook POST| WH[Tenant-registered<br/>webhook URL]

    subgraph Trust["Service trust boundary"]
        NGX
        API
        PG
        RDS
    end

    U -.->|direct upload via presigned URL| S3
```

See `ARCHITECTURE.md` for a more detailed DFD, trust boundaries, asset
inventory, and the authn/authz model used for threat modeling.

## Directory layout

```
modern-notes-saas/
├── ARCHITECTURE.md
├── docker-compose.yml
├── .env.example
├── server/
│   ├── package.json
│   ├── tsconfig.json
│   └── src/
│       ├── index.ts             # Express app + middleware wiring
│       ├── db.ts                # pg pool, redis client
│       ├── middleware/auth.ts   # JWT verification, tenant scoping
│       └── routes/
│           ├── auth.ts          # signup, login, refresh, logout
│           ├── notes.ts         # CRUD + share links + attachments
│           └── webhooks.ts      # register / rotate secret / deliver
└── web/
    ├── package.json
    ├── vite.config.ts
    └── src/
        ├── App.tsx
        └── api.ts
```

## Security posture (as designed)

- TLS everywhere at the edge; service-to-service traffic is on a private
  network.
- Argon2id for passwords, rotating refresh tokens, short-lived access JWTs.
- Per-tenant row scoping in every SQL query.
- Attachments uploaded directly via presigned URLs (API never sees bytes).
- Webhook deliveries are signed with an HMAC-SHA256 secret per subscription.
- Redis-based rate limiting on `/auth/*` and `/api/*`.

The threat model should focus on **architectural and operational** risks
(token rotation, webhook replay, SSRF via public share fetching, rate-limit
bypass, presigned URL scope, multi-tenant data isolation) rather than
obvious code-level bugs.
